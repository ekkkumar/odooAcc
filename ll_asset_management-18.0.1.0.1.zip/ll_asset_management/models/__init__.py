
from . import ll_multi_company_mixin
from . import ll_asset_mixin
from . import ll_asset_action_mixin

from . import ll_asset_config
from . import ll_asset
from . import ll_asset_issuance
from . import ll_asset_return

from . import res_company
from . import hr_employee
from . import hr_department
from . import res_partner
